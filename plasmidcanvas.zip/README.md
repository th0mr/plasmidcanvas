# plasmidcanvas - A simple Python plasmid map creator

plasmidcanvas is a python package to facilitate the creation of simple plasmid maps for mock-ups and illustrations.

Note - This project is a work in progress Python package that I am creating as part of my undergraduate project

See usage_guide/beta_install_and_usage.rst for more information


# TODO - dev install instructions ``poetry install -with dev``