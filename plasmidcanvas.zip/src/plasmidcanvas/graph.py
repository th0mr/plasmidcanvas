# TODO - Add module docstring



class Graph:

    

    def __init__(self) -> None:
        pass

    def createGraph():
        pass

    def outputToFile():
        pass

class GraphObject:

    def render():
        pass