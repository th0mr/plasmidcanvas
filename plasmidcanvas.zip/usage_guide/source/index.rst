.. plasmidcanvas_usage_guide documentation master file, created by
   sphinx-quickstart on Thu Mar  7 11:56:53 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

plasmidcanvas installation and usage guide
=====================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:


.. include:: beta_install_and_usage.rst
